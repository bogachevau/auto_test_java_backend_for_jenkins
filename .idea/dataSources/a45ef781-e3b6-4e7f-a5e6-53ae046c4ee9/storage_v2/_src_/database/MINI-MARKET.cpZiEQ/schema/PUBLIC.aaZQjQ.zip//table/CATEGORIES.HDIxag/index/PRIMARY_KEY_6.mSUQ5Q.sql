create unique index PRIMARY_KEY_6
    on CATEGORIES (ID);

